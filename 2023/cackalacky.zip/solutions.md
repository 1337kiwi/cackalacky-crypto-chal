# Step 1 | Place anywhere and identify

## Hint: What fruit is super cackalacky? + QR code
Players use the word "lime" to decode qr code with some basic encoding, and a vigenere cipher of "lime"
The hint for this here is Walpole Island. Ojibwe is a language spoken there, a google search will tell you this. There is
also the allusion to vegas, which is used later.

## decode: what happens on walpole island, stays on walpole island

# Step 2 | Place with signifier "2" so players know this is the next step.

## hint: how limes taste in a venerable language
step3: Players use the Ojibwe People's dictionary to find the word "zhiiwaa". (https://ojibwe.lib.umn.edu/search?utf8=%E2%9C%93&q=orange&commit=Search&type=english)
Players use "zhiiwaa" to decrypt message

## decode: go get a limey drink at the bar and scan your next challenge

# Step 3 | Place near/at bar

## Hint: I went to a local restaurant with an amicable staff, and they made a great cocktail to go with my garlic naan and chicken tikka masala. I just can't remember the name of the road it's on...

Players get a drink, and "mojito" will be used later as a hint. There are other drinks with limes, but mojitos are well known

Key: friendly drive

## decode: I hope you picked my favourite cocktail. Go to the CTF room, do a challenge.

Players use hints given to identify Lime and Lemon Indian Grill (Lime and indian food), and amicable

# Step 4 | Place near/at Camelia

## Hint: None, previous decode should help
"mojito" is the next encryption word. Kinda fucky, but there aren't many well known cocktails with limes, so a bit of trying different words should work.
decode: CTFs are HARD! sometimes it's a gamble if you win or not. Go take a break.


# Step 5 | Place in Outdoor Breezeway


## Hint: What state (not city!) did Artie die in after he got released from jail in 1998?
"missouri" is the keyword here. Ties into the Vegas hints given earlier, Artie Piscano from 'Casino' died in the movie, 
but he was based on Carl Angelo "Tuffy" DeLuna, who was sent to jail for 20 years and died in Kansas City, Missouri.  
https://en.wikipedia.org/wiki/Carl_DeLuna


## decode: I've got a craving for something tart and delicious. Maybe a certain pie will help me unlock the next challenge...

# Step 6 | Place near/at Oak

# Step 7 | Place near/at Camelia
