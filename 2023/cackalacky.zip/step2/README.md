This should be printed with some signifier that it is step 2 
